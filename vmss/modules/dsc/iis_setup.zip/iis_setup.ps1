Configuration iis_setup {

    Param ( [string] $nodeName = 'localhost' )

    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node $nodeName
    {
        WindowsFeature WebServerRole
        {
            Name = "Web-Server"
            Ensure = "Present"
        }
    }
}